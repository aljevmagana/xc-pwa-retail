export const einsteinAPIConfig = {
    proxyPath: `/mobify/proxy/einstein`,
    einsteinId: '',
    siteId: 'RefArch'
}
